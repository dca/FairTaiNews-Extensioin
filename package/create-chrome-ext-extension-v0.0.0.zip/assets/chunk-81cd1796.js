console.info("chrome-ext template-preact-ts background script");
